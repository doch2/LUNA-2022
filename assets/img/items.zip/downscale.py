from PIL import Image
import os


w = 400
for fn in os.listdir('.'):
    if fn.endswith('.py'):
        continue
    img = Image.open(fn)
    img = img.resize((w, int(img.size[1]*(w/img.size[0]))))
    img.save(fn)
